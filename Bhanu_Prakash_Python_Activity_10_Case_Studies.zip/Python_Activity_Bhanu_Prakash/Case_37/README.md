# Case Study 37: Nested Loop Calendar Generator

## Student details
Name: Bhanu Prakash
Section: 5
Group: CSE
Roll No.: 26000749
NIAT ID: N26V01A0369

## Problem statement
Print a monthly calendar using a starting weekday and number of days.

## Objectives
- Apply basic Python constructs to solve the problem.
- Use variables, data types, operators, conditionals, loops, strings, lists and/or tuples where appropriate.
- Validate records and present understandable results.

## Assumptions
- Sample values are illustrative and may be changed for classroom testing.
- The rules and thresholds are those stated in the program; no external database is used.
- Inputs follow the requested format except where validation is included.

## Algorithm
1. Start.
2. Set weekday and number of days.
3. Validate values.
4. Print weekday headings and leading blanks.
5. Print dates using loop.
6. End.

## Flowchart
```mermaid
flowchart TD
N0[Start] --> N1[Set weekday and number of days] --> N2[Validate values] --> N3[Print weekday headings and leading blanks] --> N4[Print dates using loop] --> N5[End]
```

## Pseudocode
```text
BEGIN
    Set weekday and number of days
    Validate values
    Print weekday headings and leading blanks
    Print dates using loop
END
```

## Python source code
See `case_37.py` in this folder.

## Test cases
| Test | Input / condition | Expected behavior |
|---|---|---|
| 1 | Typical valid sample | Produces the expected result |
| 2 | Boundary or alternate sample | Handles the case according to its rules |
| 3 | Invalid input / unmet condition where applicable | Reports or rejects it appropriately |

## Output screenshot
See `output_37.png` for representative console output.

## Conclusion
The case study demonstrates how fundamental Python concepts can process input, apply rules, and produce clear results.
