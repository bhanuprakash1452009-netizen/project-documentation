def print_calendar(start_weekday, days):
    if start_weekday not in range(7) or days not in range(1, 32):
        print("Invalid calendar values.")
        return
    print("Mon Tue Wed Thu Fri Sat Sun")
    day = 1
    for _ in range(start_weekday):
        print("    ", end="")
    while day <= days:
        print(f"{day:>3} ", end="")
        if (start_weekday + day) % 7 == 0:
            print()
        day += 1
    print()

# Monday=0 ... Sunday=6
print_calendar(3, 30)
