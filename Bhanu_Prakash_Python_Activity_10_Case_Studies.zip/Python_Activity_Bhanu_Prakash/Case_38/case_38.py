balance = 1000.0
transactions = []
while True:
    print("\n1.Deposit 2.Withdraw 3.Balance 4.Summary 5.Exit")
    choice = input("Choose: ").strip()
    if choice == "1" or choice == "2":
        try:
            amount = float(input("Amount: "))
            if amount <= 0:
                print("Amount must be positive.")
            elif choice == "1":
                balance += amount
                transactions.append(("Deposit", amount))
                print("Deposit successful.")
            elif amount > balance:
                print("Insufficient funds.")
            else:
                balance -= amount
                transactions.append(("Withdrawal", amount))
                print("Withdrawal successful.")
        except ValueError:
            print("Enter a numeric amount.")
    elif choice == "3":
        print("Balance:", format(balance, ".2f"))
    elif choice == "4":
        print("Transactions:", transactions)
        print("Current balance:", format(balance, ".2f"))
    elif choice == "5":
        print("Thank you.")
        break
    else:
        print("Invalid choice.")
