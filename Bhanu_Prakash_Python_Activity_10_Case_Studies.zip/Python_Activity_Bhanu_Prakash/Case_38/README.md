# Case Study 38: ATM Menu-Driven Banking Simulation

## Student details
Name: Bhanu Prakash
Section: 5
Group: CSE
Roll No.: 26000749
NIAT ID: N26V01A0369

## Problem statement
Simulate deposits, withdrawals, balance inquiries, and transaction summaries.

## Objectives
- Apply basic Python constructs to solve the problem.
- Use variables, data types, operators, conditionals, loops, strings, lists and/or tuples where appropriate.
- Validate records and present understandable results.

## Assumptions
- Sample values are illustrative and may be changed for classroom testing.
- The rules and thresholds are those stated in the program; no external database is used.
- Inputs follow the requested format except where validation is included.

## Algorithm
1. Start.
2. Set opening balance.
3. Display menu and read choice.
4. Validate and perform operation.
5. Update balance and transaction list.
6. Repeat until Exit.
7. End.

## Flowchart
```mermaid
flowchart TD
N0[Start] --> N1[Set opening balance] --> N2[Display menu and read choice] --> N3[Validate and perform operation] --> N4[Update balance and transaction list] --> N5[Repeat until Exit] --> N6[End]
```

## Pseudocode
```text
BEGIN
    Set opening balance
    Display menu and read choice
    Validate and perform operation
    Update balance and transaction list
    Repeat until Exit
END
```

## Python source code
See `case_38.py` in this folder.

## Test cases
| Test | Input / condition | Expected behavior |
|---|---|---|
| 1 | Typical valid sample | Produces the expected result |
| 2 | Boundary or alternate sample | Handles the case according to its rules |
| 3 | Invalid input / unmet condition where applicable | Reports or rejects it appropriately |

## Output screenshot
See `output_38.png` for representative console output.

## Conclusion
The case study demonstrates how fundamental Python concepts can process input, apply rules, and produce clear results.
