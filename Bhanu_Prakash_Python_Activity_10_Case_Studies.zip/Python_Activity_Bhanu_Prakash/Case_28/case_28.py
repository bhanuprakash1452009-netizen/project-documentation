transactions = [("T101", 250), ("T102", 1200), ("T103", 90),
                ("T101", 250), ("T104", 1800), ("T102", 1200)]
threshold = 1000
seen = []
duplicates = []
high_value = []

for transaction_id, amount in transactions:
    if transaction_id in seen:
        if transaction_id not in duplicates:
            duplicates.append(transaction_id)
    else:
        seen.append(transaction_id)
    if amount > threshold:
        high_value.append((transaction_id, amount))

print("Duplicate transaction IDs:", duplicates)
print("Transactions above", threshold, ":", high_value)
