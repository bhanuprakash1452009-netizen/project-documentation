# Case Study 28: Repeated Transaction Detection

## Student details
Name: Bhanu Prakash
Section: 5
Group: CSE
Roll No.: 26000749
NIAT ID: N26V01A0369

## Problem statement
Find duplicate transaction IDs and amounts above a specified threshold.

## Objectives
- Apply basic Python constructs to solve the problem.
- Use variables, data types, operators, conditionals, loops, strings, lists and/or tuples where appropriate.
- Validate records and present understandable results.

## Assumptions
- Sample values are illustrative and may be changed for classroom testing.
- The rules and thresholds are those stated in the program; no external database is used.
- Inputs follow the requested format except where validation is included.

## Algorithm
1. Start.
2. Set transactions and threshold.
3. Check IDs for duplicates.
4. Check amounts against threshold.
5. Print findings.
6. End.

## Flowchart
```mermaid
flowchart TD
N0[Start] --> N1[Set transactions and threshold] --> N2[Check IDs for duplicates] --> N3[Check amounts against threshold] --> N4[Print findings] --> N5[End]
```

## Pseudocode
```text
BEGIN
    Set transactions and threshold
    Check IDs for duplicates
    Check amounts against threshold
    Print findings
END
```

## Python source code
See `case_28.py` in this folder.

## Test cases
| Test | Input / condition | Expected behavior |
|---|---|---|
| 1 | Typical valid sample | Produces the expected result |
| 2 | Boundary or alternate sample | Handles the case according to its rules |
| 3 | Invalid input / unmet condition where applicable | Reports or rejects it appropriately |

## Output screenshot
See `output_28.png` for representative console output.

## Conclusion
The case study demonstrates how fundamental Python concepts can process input, apply rules, and produce clear results.
