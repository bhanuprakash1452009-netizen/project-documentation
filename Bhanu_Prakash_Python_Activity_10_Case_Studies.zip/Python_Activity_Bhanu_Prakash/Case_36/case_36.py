text = "Python is fun. Python is useful, and fun is useful."
words = []
positions = []
for raw_word in text.lower().split():
    word = raw_word.strip(".,!?;:")
    if word:
        words.append(word)

for word in words:
    if word not in positions:
        positions.append(word)

print("Word counts and positions:")
for word in positions:
    indexes = []
    for index in range(len(words)):
        if words[index] == word:
            indexes.append(index + 1)
    print(word, ":", len(indexes), "at", indexes)
print("Repeated words:", [word for word in positions if words.count(word) > 1])
