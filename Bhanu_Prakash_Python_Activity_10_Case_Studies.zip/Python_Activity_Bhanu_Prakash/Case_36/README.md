# Case Study 36: Repeated Word and Phrase Detection

## Student details
Name: Bhanu Prakash
Section: 5
Group: CSE
Roll No.: 26000749
NIAT ID: N26V01A0369

## Problem statement
Normalize a paragraph, count words, and report repeated words and their positions.

## Objectives
- Apply basic Python constructs to solve the problem.
- Use variables, data types, operators, conditionals, loops, strings, lists and/or tuples where appropriate.
- Validate records and present understandable results.

## Assumptions
- Sample values are illustrative and may be changed for classroom testing.
- The rules and thresholds are those stated in the program; no external database is used.
- Inputs follow the requested format except where validation is included.

## Algorithm
1. Start.
2. Read paragraph.
3. Normalize case and split words.
4. Remove basic punctuation.
5. Count words and positions.
6. Print repeated words.
7. End.

## Flowchart
```mermaid
flowchart TD
N0[Start] --> N1[Read paragraph] --> N2[Normalize case and split words] --> N3[Remove basic punctuation] --> N4[Count words and positions] --> N5[Print repeated words] --> N6[End]
```

## Pseudocode
```text
BEGIN
    Read paragraph
    Normalize case and split words
    Remove basic punctuation
    Count words and positions
    Print repeated words
END
```

## Python source code
See `case_36.py` in this folder.

## Test cases
| Test | Input / condition | Expected behavior |
|---|---|---|
| 1 | Typical valid sample | Produces the expected result |
| 2 | Boundary or alternate sample | Handles the case according to its rules |
| 3 | Invalid input / unmet condition where applicable | Reports or rejects it appropriately |

## Output screenshot
See `output_36.png` for representative console output.

## Conclusion
The case study demonstrates how fundamental Python concepts can process input, apply rules, and produce clear results.
