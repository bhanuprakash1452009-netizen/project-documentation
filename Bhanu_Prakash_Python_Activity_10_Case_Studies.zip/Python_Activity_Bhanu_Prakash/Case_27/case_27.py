def hollow_diamond(width):
    if width < 1 or width % 2 == 0:
        raise ValueError("Width must be a positive odd number.")
    mid = width // 2
    lines = []
    for row in range(width):
        distance = abs(mid - row)
        outer = distance
        inner = width - 2 * distance - 2
        if inner < 0:
            lines.append(" " * outer + "*")
        else:
            lines.append(" " * outer + "*" + " " * inner + "*")
    return "\n".join(lines)

try:
    width = int(input("Enter an odd width: "))
    print(hollow_diamond(width))
except ValueError as error:
    print("Invalid input:", error)
