# Case Study 30: Student Email and Identifier Validation

## Student details
Name: Bhanu Prakash
Section: 5
Group: CSE
Roll No.: 26000749
NIAT ID: N26V01A0369

## Problem statement
Validate email-like strings and student identifiers using basic string operations.

## Objectives
- Apply basic Python constructs to solve the problem.
- Use variables, data types, operators, conditionals, loops, strings, lists and/or tuples where appropriate.
- Validate records and present understandable results.

## Assumptions
- Sample values are illustrative and may be changed for classroom testing.
- The rules and thresholds are those stated in the program; no external database is used.
- Inputs follow the requested format except where validation is included.

## Algorithm
1. Start.
2. Read email and student ID.
3. Split and validate email fields.
4. Check ID length and character positions.
5. Print validation results.
6. End.

## Flowchart
```mermaid
flowchart TD
N0[Start] --> N1[Read email and student ID] --> N2[Split and validate email fields] --> N3[Check ID length and character positions] --> N4[Print validation results] --> N5[End]
```

## Pseudocode
```text
BEGIN
    Read email and student ID
    Split and validate email fields
    Check ID length and character positions
    Print validation results
END
```

## Python source code
See `case_30.py` in this folder.

## Test cases
| Test | Input / condition | Expected behavior |
|---|---|---|
| 1 | Typical valid sample | Produces the expected result |
| 2 | Boundary or alternate sample | Handles the case according to its rules |
| 3 | Invalid input / unmet condition where applicable | Reports or rejects it appropriately |

## Output screenshot
See `output_30.png` for representative console output.

## Conclusion
The case study demonstrates how fundamental Python concepts can process input, apply rules, and produce clear results.
