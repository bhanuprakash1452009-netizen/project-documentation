def valid_email(email):
    parts = email.split("@")
    if len(parts) != 2:
        return False
    local, domain = parts
    return (bool(local) and bool(domain) and "." in domain
            and not email.startswith(".") and not email.endswith(".")
            and " " not in email)

def valid_student_id(identifier):
    # Required format: 2 letters, 8 digits, then 1 letter (example: CS26000074A)
    if len(identifier) != 11:
        return False
    return (identifier[:2].isalpha() and identifier[2:10].isdigit()
            and identifier[10].isalpha())

emails = ["student@example.edu", "bad-email", "a b@school.in"]
ids = ["CS2600074A", "C12600074A", "CS26A0074A"]
for value in emails:
    print(value, "->", "Valid" if valid_email(value) else "Invalid")
for value in ids:
    print(value, "->", "Valid" if valid_student_id(value) else "Invalid")
