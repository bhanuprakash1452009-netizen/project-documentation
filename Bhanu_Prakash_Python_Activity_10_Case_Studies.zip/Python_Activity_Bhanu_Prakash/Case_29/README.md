# Case Study 29: Password Policy Validation Engine

## Student details
Name: Bhanu Prakash
Section: 5
Group: CSE
Roll No.: 26000749
NIAT ID: N26V01A0369

## Problem statement
Check sample passwords against length, character-category, repetition, and prohibited-substring rules.

## Objectives
- Apply basic Python constructs to solve the problem.
- Use variables, data types, operators, conditionals, loops, strings, lists and/or tuples where appropriate.
- Validate records and present understandable results.

## Assumptions
- Sample values are illustrative and may be changed for classroom testing.
- The rules and thresholds are those stated in the program; no external database is used.
- Inputs follow the requested format except where validation is included.

## Algorithm
1. Start.
2. Read/sample password.
3. Check length and character categories.
4. Check prohibited word and repeated characters.
5. Collect failed rules.
6. Print result.
7. End.

## Flowchart
```mermaid
flowchart TD
N0[Start] --> N1[Read/sample password] --> N2[Check length and character categories] --> N3[Check prohibited word and repeated characters] --> N4[Collect failed rules] --> N5[Print result] --> N6[End]
```

## Pseudocode
```text
BEGIN
    Read/sample password
    Check length and character categories
    Check prohibited word and repeated characters
    Collect failed rules
    Print result
END
```

## Python source code
See `case_29.py` in this folder.

## Test cases
| Test | Input / condition | Expected behavior |
|---|---|---|
| 1 | Typical valid sample | Produces the expected result |
| 2 | Boundary or alternate sample | Handles the case according to its rules |
| 3 | Invalid input / unmet condition where applicable | Reports or rejects it appropriately |

## Output screenshot
See `output_29.png` for representative console output.

## Conclusion
The case study demonstrates how fundamental Python concepts can process input, apply rules, and produce clear results.
