def validate_password(password):
    issues = []
    if len(password) < 8:
        issues.append("must contain at least 8 characters")
    if not any(ch.islower() for ch in password):
        issues.append("needs a lowercase letter")
    if not any(ch.isupper() for ch in password):
        issues.append("needs an uppercase letter")
    if not any(ch.isdigit() for ch in password):
        issues.append("needs a digit")
    if not any(not ch.isalnum() for ch in password):
        issues.append("needs a symbol")
    if "password" in password.lower():
        issues.append("contains prohibited word 'password'")
    if any(password[i] == password[i+1] == password[i+2]
           for i in range(len(password)-2)):
        issues.append("has 3 identical consecutive characters")
    return issues

samples = ["Campus#2026", "password1", "Ab1!", "AaaB123!"]
for sample in samples:
    issues = validate_password(sample)
    print(sample, "->", "Valid" if not issues else "; ".join(issues))
