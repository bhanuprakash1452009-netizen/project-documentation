# Case Study 34: Student Feedback Sentiment Scoring

## Student details
Name: Bhanu Prakash
Section: 5
Group: CSE
Roll No.: 26000749
NIAT ID: N26V01A0369

## Problem statement
Score feedback using supplied positive and negative keywords and classify it.

## Objectives
- Apply basic Python constructs to solve the problem.
- Use variables, data types, operators, conditionals, loops, strings, lists and/or tuples where appropriate.
- Validate records and present understandable results.

## Assumptions
- Sample values are illustrative and may be changed for classroom testing.
- The rules and thresholds are those stated in the program; no external database is used.
- Inputs follow the requested format except where validation is included.

## Algorithm
1. Start.
2. Read feedback and keyword lists.
3. Count positive and negative words.
4. Calculate score.
5. Classify score.
6. Print score and label.
7. End.

## Flowchart
```mermaid
flowchart TD
N0[Start] --> N1[Read feedback and keyword lists] --> N2[Count positive and negative words] --> N3[Calculate score] --> N4[Classify score] --> N5[Print score and label] --> N6[End]
```

## Pseudocode
```text
BEGIN
    Read feedback and keyword lists
    Count positive and negative words
    Calculate score
    Classify score
    Print score and label
END
```

## Python source code
See `case_34.py` in this folder.

## Test cases
| Test | Input / condition | Expected behavior |
|---|---|---|
| 1 | Typical valid sample | Produces the expected result |
| 2 | Boundary or alternate sample | Handles the case according to its rules |
| 3 | Invalid input / unmet condition where applicable | Reports or rejects it appropriately |

## Output screenshot
See `output_34.png` for representative console output.

## Conclusion
The case study demonstrates how fundamental Python concepts can process input, apply rules, and produce clear results.
