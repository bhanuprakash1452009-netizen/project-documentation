positive_words = ["good", "helpful", "excellent", "clear", "enjoy"]
negative_words = ["bad", "confusing", "slow", "difficult", "poor"]
feedback = [
    "The lesson was clear and helpful",
    "The task was confusing and difficult",
    "Excellent session, I enjoy learning"
]
for sentence in feedback:
    words = sentence.lower().split()
    positive = sum(words.count(word) for word in positive_words)
    negative = sum(words.count(word) for word in negative_words)
    score = positive - negative
    if score > 0:
        label = "Positive"
    elif score < 0:
        label = "Negative"
    else:
        label = "Neutral"
    print(sentence, "-> score:", score, "|", label)
