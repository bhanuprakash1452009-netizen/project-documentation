# Case Study 35: Text Compression Using Character Runs

## Student details
Name: Bhanu Prakash
Section: 5
Group: CSE
Roll No.: 26000749
NIAT ID: N26V01A0369

## Problem statement
Encode consecutive repeated characters and use the encoding only when it is shorter.

## Objectives
- Apply basic Python constructs to solve the problem.
- Use variables, data types, operators, conditionals, loops, strings, lists and/or tuples where appropriate.
- Validate records and present understandable results.

## Assumptions
- Sample values are illustrative and may be changed for classroom testing.
- The rules and thresholds are those stated in the program; no external database is used.
- Inputs follow the requested format except where validation is included.

## Algorithm
1. Start.
2. Read text.
3. Group consecutive equal characters.
4. Build run-length encoding.
5. Use encoding only if shorter.
6. Print result.
7. End.

## Flowchart
```mermaid
flowchart TD
N0[Start] --> N1[Read text] --> N2[Group consecutive equal characters] --> N3[Build run-length encoding] --> N4[Use encoding only if shorter] --> N5[Print result] --> N6[End]
```

## Pseudocode
```text
BEGIN
    Read text
    Group consecutive equal characters
    Build run-length encoding
    Use encoding only if shorter
    Print result
END
```

## Python source code
See `case_35.py` in this folder.

## Test cases
| Test | Input / condition | Expected behavior |
|---|---|---|
| 1 | Typical valid sample | Produces the expected result |
| 2 | Boundary or alternate sample | Handles the case according to its rules |
| 3 | Invalid input / unmet condition where applicable | Reports or rejects it appropriately |

## Output screenshot
See `output_35.png` for representative console output.

## Conclusion
The case study demonstrates how fundamental Python concepts can process input, apply rules, and produce clear results.
