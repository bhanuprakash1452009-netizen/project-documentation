def run_length_encode(text):
    if not text:
        return ""
    encoded = []
    count = 1
    for index in range(1, len(text)):
        if text[index] == text[index - 1]:
            count += 1
        else:
            encoded.append(text[index - 1] + str(count))
            count = 1
    encoded.append(text[-1] + str(count))
    result = "".join(encoded)
    return result if len(result) < len(text) else text

samples = ["aaabbcccc", "abcdef", "", "xxxxxyy"]
for sample in samples:
    result = run_length_encode(sample)
    print(repr(sample), "=>", repr(result),
          "| original:", len(sample), "encoded:", len(result))
