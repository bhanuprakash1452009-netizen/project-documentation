attendance = 82
lab_completed = True
internal_marks = 18
fees_cleared = False

requirements = [
    ("Attendance at least 75%", attendance >= 75),
    ("All laboratory work completed", lab_completed),
    ("Internal marks at least 15/30", internal_marks >= 15),
    ("Fees cleared", fees_cleared)
]
unmet = []
for description, satisfied in requirements:
    print(description + ":", "Met" if satisfied else "Not met")
    if not satisfied:
        unmet.append(description)

if unmet:
    print("Result: NOT ELIGIBLE")
    print("Outstanding:", unmet)
else:
    print("Result: ELIGIBLE")
