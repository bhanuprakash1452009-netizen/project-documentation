# Case Study 39: Multi-Stage Examination Eligibility System

## Student details
Name: Bhanu Prakash
Section: 5
Group: CSE
Roll No.: 26000749
NIAT ID: N26V01A0369

## Problem statement
Check attendance, lab completion, internal marks, and fee clearance; report unmet conditions.

## Objectives
- Apply basic Python constructs to solve the problem.
- Use variables, data types, operators, conditionals, loops, strings, lists and/or tuples where appropriate.
- Validate records and present understandable results.

## Assumptions
- Sample values are illustrative and may be changed for classroom testing.
- The rules and thresholds are those stated in the program; no external database is used.
- Inputs follow the requested format except where validation is included.

## Algorithm
1. Start.
2. Read eligibility data.
3. Check each requirement.
4. Collect unmet conditions.
5. Print eligibility and reasons.
6. End.

## Flowchart
```mermaid
flowchart TD
N0[Start] --> N1[Read eligibility data] --> N2[Check each requirement] --> N3[Collect unmet conditions] --> N4[Print eligibility and reasons] --> N5[End]
```

## Pseudocode
```text
BEGIN
    Read eligibility data
    Check each requirement
    Collect unmet conditions
    Print eligibility and reasons
END
```

## Python source code
See `case_39.py` in this folder.

## Test cases
| Test | Input / condition | Expected behavior |
|---|---|---|
| 1 | Typical valid sample | Produces the expected result |
| 2 | Boundary or alternate sample | Handles the case according to its rules |
| 3 | Invalid input / unmet condition where applicable | Reports or rejects it appropriately |

## Output screenshot
See `output_39.png` for representative console output.

## Conclusion
The case study demonstrates how fundamental Python concepts can process input, apply rules, and produce clear results.
