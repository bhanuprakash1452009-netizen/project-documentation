# Python Activity-Based Learning — 10 Case Studies

## Student details
Name: Bhanu Prakash
Section: 5
Group: CSE
Roll No.: 26000749
NIAT ID: N26V01A0369

## Selected case studies
1. Case 27: Advanced Numeric Pattern Generator
2. Case 28: Repeated Transaction Detection
3. Case 29: Password Policy Validation Engine
4. Case 30: Student Email and Identifier Validation
5. Case 35: Text Compression Using Character Runs
6. Case 36: Repeated Word and Phrase Detection
7. Case 37: Nested Loop Calendar Generator
8. Case 38: ATM Menu-Driven Banking Simulation
9. Case 39: Multi-Stage Examination Eligibility System
10. Case 34: Student Feedback Sentiment Scoring

Each case folder contains a Python source file, solution write-up, algorithm, flowchart (Mermaid source), pseudocode, test-case outline, and representative console output screenshot.

## Run
Use Python 3:
`python Case_27/case_27.py`

Some programs use fixed sample data; the ATM and pattern generator accept console input. Update sample values as needed for your faculty's exact test scenarios.

**Note:** The PDF requires uploading the materials to a student-owned GitHub repository named `Python-Activity-Based-Learning`. This ZIP is a prepared local package; review the assumptions and test cases, then upload it to your repository.
